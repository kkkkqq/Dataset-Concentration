export CUDA_VISIBLE_DEVICES='0,1'

cd ../..

# python validate.py \
# --syn-data-path /datahdd/tfliu/samples/DiT/extracted/orig/imagenet1k/ipc10/001 --ipc 10 \
# --val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8

python validate.py \
--syn-data-path /datahdd/tfliu/samples/DiT/extracted/orig/imagenet1k/ipc50/001 --ipc 50 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8

python validate.py \
--syn-data-path /datahdd/tfliu/samples/DiT/extracted/orig/imagenet1k/ipc10/002 --ipc 10 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8

python validate.py \
--syn-data-path /datahdd/tfliu/samples/DiT/extracted/orig/imagenet1k/ipc50/002 --ipc 50 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8

python validate.py \
--syn-data-path /datahdd/tfliu/samples/DiT/extracted/orig/imagenet1k/ipc10/003 --ipc 10 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8

python validate.py \
--syn-data-path /datahdd/tfliu/samples/DiT/extracted/orig/imagenet1k/ipc50/003 --ipc 50 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8

