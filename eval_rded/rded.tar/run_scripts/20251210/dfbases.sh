export CUDA_VISIBLE_DEVICES='4'

cd ../..


arch=mobilenet_v2

echo --------------------------${arch}-10IPC-------------------
python validate.py \
--syn-data-path /datassd/dfbases/imagenet1k/ipc10 --ipc 10 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}

echo --------------------------${arch}-50IPC-------------------
python validate.py \
--syn-data-path /datassd/dfbases/imagenet1k/ipc50 --ipc 50 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}  --re-accum-steps 2

arch=efficientnet_b0

echo --------------------------${arch}-10IPC-------------------
python validate.py \
--syn-data-path /datassd/dfbases/imagenet1k/ipc10 --ipc 10 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}

echo --------------------------${arch}-50IPC-------------------
python validate.py \
--syn-data-path /datassd/dfbases/imagenet1k/ipc50 --ipc 50 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}  --re-accum-steps 2

export CUDA_VISIBLE_DEVICES='4,5,6,7'
arch=swin_v2_b 

echo --------------------------${arch}-10IPC-------------------
python validate.py \
--syn-data-path /datassd/dfbases/imagenet1k/ipc10 --ipc 10 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}

echo --------------------------${arch}-50IPC-------------------
python validate.py \
--syn-data-path /datassd/dfbases/imagenet1k/ipc50 --ipc 50 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch} --re-accum-steps 2
