export CUDA_VISIBLE_DEVICES='2'

cd ../..

arch=resnet18

# echo --------------------------${arch}-10IPC-------------------
# python validate.py \
# --syn-data-path /datassd/bases/imagenet1k/ipc10 --ipc 10 \
# --val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
# --stud-name ${arch}

# echo --------------------------${arch}-50IPC-------------------
# python validate.py \
# --syn-data-path /datassd/bases/imagenet1k/ipc50 --ipc 50 \
# --val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
# --stud-name ${arch}

# arch=efficientnet_b0

# # echo --------------------------${arch}-10IPC-------------------
# # python validate.py \
# # --syn-data-path /datassd/bases/imagenet1k/ipc10 --ipc 10 \
# # --val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
# # --stud-name ${arch}

# echo --------------------------${arch}-50IPC-------------------
# python validate.py \
# --syn-data-path /datassd/bases/imagenet1k/ipc50 --ipc 50 \
# --val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
# --stud-name ${arch} --re-accum-steps 2

arch=mobilenet_v2

# echo --------------------------${arch}-10IPC-------------------
# python validate.py \
# --syn-data-path /datassd/bases/imagenet1k/ipc10 --ipc 10 \
# --val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
# --stud-name ${arch} --re-accum-steps 4

echo --------------------------${arch}-50IPC-------------------
python validate.py \
--syn-data-path /datassd/bases/imagenet1k/ipc50 --ipc 50 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch} --re-accum-steps 2

export CUDA_VISIBLE_DEVICES='0,1,2,3'

arch=swin_v2_b

echo --------------------------${arch}-10IPC-------------------
python validate.py \
--syn-data-path /datassd/bases/imagenet1k/ipc10 --ipc 10 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}

echo --------------------------${arch}-50IPC-------------------
python validate.py \
--syn-data-path /datassd/bases/imagenet1k/ipc50 --ipc 50 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch} --re-accum-steps 2

# arch=resnet101
# echo --------------------------${arch}-10IPC-------------------
# python validate.py \
# --syn-data-path /datassd/bases/imagenet1k/ipc10 --ipc 10 \
# --val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
# --stud-name ${arch} --re-accum-steps 4

# echo --------------------------${arch}-50IPC-------------------
# python validate.py \
# --syn-data-path /datassd/bases/imagenet1k/ipc50 --ipc 50 \
# --val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
# --stud-name ${arch} --re-accum-steps 4
