export CUDA_VISIBLE_DEVICES='6'

cd ../..

arch=resnet18

echo --------------------------${arch}-10IPC-------------------
python validate.py \
--syn-data-path /datassd/bases/imagenet1k/ipc10 --ipc 10 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}

echo --------------------------${arch}-50IPC-------------------
python validate.py \
--syn-data-path /datassd/bases/imagenet1k/ipc50 --ipc 50 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}

arch=efficientnet_b0

echo --------------------------${arch}-10IPC-------------------
python validate.py \
--syn-data-path /datassd/bases/imagenet1k/ipc10 --ipc 10 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}

echo --------------------------${arch}-50IPC-------------------
python validate.py \
--syn-data-path /datassd/bases/imagenet1k/ipc50 --ipc 50 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}

arch=mobilenet_v2

echo --------------------------${arch}-10IPC-------------------
python validate.py \
--syn-data-path /datassd/bases/imagenet1k/ipc10 --ipc 10 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}

echo --------------------------${arch}-50IPC-------------------
python validate.py \
--syn-data-path /datassd/bases/imagenet1k/ipc50 --ipc 50 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}

arch=swin_v2_t

echo --------------------------${arch}-10IPC-------------------
python validate.py \
--syn-data-path /datassd/bases/imagenet1k/ipc10 --ipc 10 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}

echo --------------------------${arch}-50IPC-------------------
python validate.py \
--syn-data-path /datassd/bases/imagenet1k/ipc50 --ipc 50 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}

arch=resnet101
echo --------------------------${arch}-10IPC-------------------
python validate.py \
--syn-data-path /datassd/bases/imagenet1k/ipc10 --ipc 10 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}

echo --------------------------${arch}-50IPC-------------------
python validate.py \
--syn-data-path /datassd/bases/imagenet1k/ipc50 --ipc 50 \
--val-dir /datahdd/imagenet-val/val --subset imagenet-1k --workers 8 \
--stud-name ${arch}
